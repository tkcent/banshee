-- MySQL dump 10.15  Distrib 10.0.34-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: banshee_dev
-- ------------------------------------------------------
-- Server version	10.0.33-MariaDB-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `agenda`
--

DROP TABLE IF EXISTS `agenda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agenda` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `begin` date DEFAULT NULL,
  `end` date DEFAULT NULL,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agenda`
--

LOCK TABLES `agenda` WRITE;
/*!40000 ALTER TABLE `agenda` DISABLE KEYS */;
INSERT INTO `agenda` VALUES (1,'2016-06-13','2016-06-13','Test','This is a test.');
/*!40000 ALTER TABLE `agenda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `key` varchar(100) NOT NULL,
  `value` mediumtext NOT NULL,
  `timeout` datetime NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collection_album`
--

DROP TABLE IF EXISTS `collection_album`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collection_album` (
  `collection_id` int(10) unsigned NOT NULL,
  `album_id` int(10) unsigned NOT NULL,
  KEY `collection_id` (`collection_id`),
  KEY `album_id` (`album_id`),
  CONSTRAINT `collection_album_ibfk_1` FOREIGN KEY (`collection_id`) REFERENCES `collections` (`id`),
  CONSTRAINT `collection_album_ibfk_2` FOREIGN KEY (`album_id`) REFERENCES `photo_albums` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collection_album`
--

LOCK TABLES `collection_album` WRITE;
/*!40000 ALTER TABLE `collection_album` DISABLE KEYS */;
/*!40000 ALTER TABLE `collection_album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collections`
--

DROP TABLE IF EXISTS `collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collections` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collections`
--

LOCK TABLES `collections` WRITE;
/*!40000 ALTER TABLE `collections` DISABLE KEYS */;
/*!40000 ALTER TABLE `collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dictionary`
--

DROP TABLE IF EXISTS `dictionary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dictionary` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `word` varchar(100) NOT NULL,
  `short_description` text NOT NULL,
  `long_description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dictionary`
--

LOCK TABLES `dictionary` WRITE;
/*!40000 ALTER TABLE `dictionary` DISABLE KEYS */;
INSERT INTO `dictionary` VALUES (1,'Hiawatha','Hiawatha webserver','The secure and advanced Hiawatha webserver. So cool!'),(3,'Banshee','Banshee PHP framework','The secure Banshee PHP framework. Nice!');
/*!40000 ALTER TABLE `dictionary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dummy`
--

DROP TABLE IF EXISTS `dummy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dummy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `number` int(11) NOT NULL,
  `line` varchar(50) NOT NULL,
  `text` text NOT NULL,
  `boolean` tinyint(1) NOT NULL,
  `date` date NOT NULL,
  `timestamp` timestamp NULL DEFAULT NULL,
  `enum` enum('value1','value2','value3') NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `dummy_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dummy`
--

LOCK TABLES `dummy` WRITE;
/*!40000 ALTER TABLE `dummy` DISABLE KEYS */;
INSERT INTO `dummy` VALUES (1,72,'hello world','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus erat urna, accumsan at, mattis eu, euismod nec, justo. Integer consectetur. Aliquam erat volutpat. Sed ac ipsum. Maecenas pretium, felis non blandit pellentesque, arcu nulla adipiscing dui, ac sollicitudin ipsum nisl a dolor. Praesent in dolor consequat massa molestie mollis. In viverra eleifend purus. Nunc vel sapien. Etiam risus. Morbi auctor commodo nunc. In hac habitasse platea dictumst. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse posuere lectus non sapien. Mauris congue dolor a magna.\r\n\r\nMauris tristique justo ac sem. Vivamus pharetra quam et nunc. Proin quis erat. Proin pharetra mattis enim. Sed diam. Aliquam tempor eros sed odio aliquam fringilla. Nulla posuere. Phasellus eleifend sem a odio feugiat vehicula. Integer dignissim, est sed consectetur vestibulum, massa arcu ultrices nulla, ac consequat ligula justo at tellus. Etiam interdum est quis felis. Mauris lacinia.',0,'2009-02-18','2015-10-05 19:51:00','value2',NULL),(2,23,'Lorum ipsum','ouifhilduvnxaifs driaurfc iweurnfcisaeurnbc iseruvsieurbviaceurbnfc iscdbn ilzdbv sraerf ase rgc sr cae rgv sfgb vaergcfh seirfc togvcn eufnseirgubc sertcgse riguncs eriuneizrung caieunrfgc iaeurb vsiubre viseurb viauerf ciaseur vciauwe nrisuviaeruniapwuenfc awijf wrtunh gviasuebr vciaubervn isubeviauebrf isbv iauebrf iauebnrv iaunerv iaubf visuubenrv iaeubnrfv aiebviAHWBE FIWY4BTGV9QUHB3 FIAUUBFPIUbi suuebrfiauuwbef istrbv isdbfv aidfvb',1,'2009-01-23','2015-10-01 10:00:00','value3',1);
/*!40000 ALTER TABLE `dummy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faq_sections`
--

DROP TABLE IF EXISTS `faq_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faq_sections` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `label` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faq_sections`
--

LOCK TABLES `faq_sections` WRITE;
/*!40000 ALTER TABLE `faq_sections` DISABLE KEYS */;
INSERT INTO `faq_sections` VALUES (1,'Location'),(2,'Person');
/*!40000 ALTER TABLE `faq_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faqs`
--

DROP TABLE IF EXISTS `faqs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faqs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `section_id` int(10) unsigned NOT NULL,
  `question` tinytext NOT NULL,
  `answer` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `section_id` (`section_id`),
  CONSTRAINT `faqs_ibfk_1` FOREIGN KEY (`section_id`) REFERENCES `faq_sections` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faqs`
--

LOCK TABLES `faqs` WRITE;
/*!40000 ALTER TABLE `faqs` DISABLE KEYS */;
INSERT INTO `faqs` VALUES (1,1,'Where is it?','It is here!'),(2,2,'Who are you?','I am me!'),(3,2,'Who is that?','That is him.');
/*!40000 ALTER TABLE `faqs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flags`
--

DROP TABLE IF EXISTS `flags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(10) unsigned NOT NULL,
  `module` varchar(50) NOT NULL,
  `flag` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flags`
--

LOCK TABLES `flags` WRITE;
/*!40000 ALTER TABLE `flags` DISABLE KEYS */;
/*!40000 ALTER TABLE `flags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_last_view`
--

DROP TABLE IF EXISTS `forum_last_view`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_last_view` (
  `user_id` int(10) unsigned NOT NULL,
  `last_view` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `forum_last_view_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum_last_view`
--

LOCK TABLES `forum_last_view` WRITE;
/*!40000 ALTER TABLE `forum_last_view` DISABLE KEYS */;
INSERT INTO `forum_last_view` VALUES (1,'2018-04-04 17:53:02');
/*!40000 ALTER TABLE `forum_last_view` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_messages`
--

DROP TABLE IF EXISTS `forum_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `topic_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `content` text NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `topic_id` (`topic_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `forum_messages_ibfk_1` FOREIGN KEY (`topic_id`) REFERENCES `forum_topics` (`id`),
  CONSTRAINT `forum_messages_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum_messages`
--

LOCK TABLES `forum_messages` WRITE;
/*!40000 ALTER TABLE `forum_messages` DISABLE KEYS */;
INSERT INTO `forum_messages` VALUES (1,1,1,NULL,'2013-04-30 08:54:44','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean ac elit quam. Nullam aliquam justo et nisi dictum pretium interdum tellus hendrerit. Aenean tristique posuere dictum. Maecenas nec sapien ut magna suscipit euismod quis ut metus. Aenean sit amet metus a turpis iaculis mollis. Nam faucibus mauris vel ligula ultricies dapibus. Nullam quis orci ac sem convallis malesuada nec id nisi. Praesent quis tellus nec sapien viverra blandit at ut erat. Curabitur bibendum malesuada erat, in suscipit leo porta et. Cras quis arcu sit amet nibh molestie mollis eu eget nulla. Vivamus sed enim fringilla elit pretium feugiat. Nullam elementum fermentum nunc in sodales.\r\n\r\nMauris nec nunc quis enim porttitor consectetur at et lorem. Vivamus ac rutrum sapien. Nullam metus lectus, lobortis sit amet vulputate sit amet, fermentum sed velit. Phasellus ac libero urna. Maecenas tellus massa, ultrices sed pretium non, faucibus ut lorem. Donec aliquam vehicula ante, eu sodales felis ullamcorper at. Sed sed odio ipsum. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nullam laoreet tristique est in molestie. Sed lacinia euismod porttitor. Praesent ullamcorper fringilla arcu sit amet viverra. Aliquam erat volutpat.\r\n\r\nNulla vel eros quam. Nam nec turpis ac turpis pulvinar facilisis non non nunc. Nam bibendum nunc in velit cursus rutrum. Integer at ultricies orci. Suspendisse vitae sodales dui. Integer malesuada hendrerit dui, a ullamcorper mauris aliquam sit amet. Nulla dignissim tortor accumsan velit laoreet non eleifend massa aliquet. Quisque luctus dapibus viverra. Aliquam sed lorem diam. Phasellus condimentum lectus vitae ipsum molestie a vestibulum risus malesuada. Duis posuere urna a arcu facilisis sit amet blandit lacus tempus. Vestibulum vel arcu nunc, ut imperdiet massa. Donec congue risus nec urna laoreet et euismod magna semper. Fusce pharetra porttitor ultrices.','84.29.202.23');
/*!40000 ALTER TABLE `forum_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_topics`
--

DROP TABLE IF EXISTS `forum_topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_topics` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `forum_id` int(10) unsigned NOT NULL,
  `subject` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `forum_id` (`forum_id`),
  CONSTRAINT `forum_topics_ibfk_1` FOREIGN KEY (`forum_id`) REFERENCES `forums` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum_topics`
--

LOCK TABLES `forum_topics` WRITE;
/*!40000 ALTER TABLE `forum_topics` DISABLE KEYS */;
INSERT INTO `forum_topics` VALUES (1,1,'Lorum ipsum');
/*!40000 ALTER TABLE `forum_topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forums`
--

DROP TABLE IF EXISTS `forums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forums` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `description` varchar(100) NOT NULL,
  `order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forums`
--

LOCK TABLES `forums` WRITE;
/*!40000 ALTER TABLE `forums` DISABLE KEYS */;
INSERT INTO `forums` VALUES (1,'Lorum ipsum','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer a purus velit, et porttitor diam.',1);
/*!40000 ALTER TABLE `forums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guestbook`
--

DROP TABLE IF EXISTS `guestbook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guestbook` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `author` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ip_address` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guestbook`
--

LOCK TABLES `guestbook` WRITE;
/*!40000 ALTER TABLE `guestbook` DISABLE KEYS */;
INSERT INTO `guestbook` VALUES (1,'Piet','Hoi!','2017-08-22 10:49:41','46.144.3.66');
/*!40000 ALTER TABLE `guestbook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `languages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `en` text NOT NULL,
  `nl` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `page` (`page`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `languages`
--

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
INSERT INTO `languages` VALUES (1,'*','test','Test','Test');
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `link_categories`
--

DROP TABLE IF EXISTS `link_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `link_categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `category` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `link_categories`
--

LOCK TABLES `link_categories` WRITE;
/*!40000 ALTER TABLE `link_categories` DISABLE KEYS */;
INSERT INTO `link_categories` VALUES (1,'Websites');
/*!40000 ALTER TABLE `link_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `links`
--

DROP TABLE IF EXISTS `links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `links` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `text` varchar(100) NOT NULL,
  `link` tinytext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `links_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `link_categories` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `links`
--

LOCK TABLES `links` WRITE;
/*!40000 ALTER TABLE `links` DISABLE KEYS */;
INSERT INTO `links` VALUES (1,1,'Hiawatha webserver','https://www.hiawatha-webserver.org/'),(2,1,'Banshee PHP framework','https://www.banshee-php.org/');
/*!40000 ALTER TABLE `links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_clients`
--

DROP TABLE IF EXISTS `log_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `os` tinytext NOT NULL,
  `browser` tinytext NOT NULL,
  `date` date NOT NULL,
  `count` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_clients`
--

LOCK TABLES `log_clients` WRITE;
/*!40000 ALTER TABLE `log_clients` DISABLE KEYS */;
INSERT INTO `log_clients` VALUES (1,'Windows','Firefox','2016-09-19',1),(2,'Windows','Firefox','2016-09-20',1),(3,'Windows','Firefox','2016-09-21',1),(4,'Windows','Firefox','2016-09-22',1),(5,'iOS','Safari','2016-09-23',1),(6,'Windows','Internet Explorer','2016-09-24',1),(7,'Windows','Gecko','2016-09-26',1),(8,'Windows','Firefox','2016-09-27',2),(9,'Windows','Gecko','2016-09-28',1),(10,'Windows','Firefox','2016-09-28',1),(11,'Windows','Firefox','2016-09-29',4),(12,'Windows','Gecko','2016-09-30',2),(13,'Windows','Gecko','2016-10-01',4),(14,'Windows','Gecko','2016-10-04',1),(15,'Windows','Gecko','2016-10-10',3),(16,'Windows','Gecko','2016-10-11',169),(17,'Windows','Gecko','2016-10-12',1),(18,'Windows','Gecko','2016-10-17',5),(19,'Windows','Gecko','2016-10-18',2),(20,'iOS','Safari','2016-10-19',1),(21,'Mac OS X','Firefox','2016-10-19',1),(22,'Mac OS X','Firefox','2016-10-22',2),(23,'Windows','Firefox','2016-10-22',1),(24,'Mac OS X','Firefox','2016-10-26',2),(25,'Windows','Gecko','2016-10-31',1),(26,'Windows','Gecko','2016-11-02',1),(27,'iOS','Safari','2016-11-13',1),(28,'Mac OS X','Firefox','2016-11-13',1),(29,'Windows','Gecko','2016-11-16',1),(30,'Windows','Firefox','2016-11-16',2),(31,'Mac OS X','Firefox','2016-11-16',1),(32,'Windows','Gecko','2016-11-17',3),(33,'Mac OS X','Firefox','2016-11-17',2),(34,'Windows','Firefox','2016-11-17',2),(35,'Mac OS X','Firefox','2016-11-18',1),(36,'iOS','Safari','2016-11-20',2),(37,'Windows','Gecko','2016-11-21',2),(38,'Mac OS X','Firefox','2016-11-23',1),(39,'Mac OS X','Firefox','2016-11-24',2),(40,'Mac OS X','Firefox','2016-11-25',1),(41,'Mac OS X','Firefox','2016-11-27',2),(42,'Windows','Gecko','2016-11-28',1),(43,'Mac OS X','Firefox','2016-11-28',2),(44,'Windows','Gecko','2016-11-30',1),(45,'Mac OS X','Firefox','2016-11-30',1),(46,'Mac OS X','Firefox','2016-12-01',1),(47,'Mac OS X','Firefox','2016-12-02',2),(48,'Windows','Firefox','2016-12-03',3),(49,'Windows','Gecko','2016-12-06',1),(50,'Windows','Gecko','2016-12-13',3),(51,'Mac OS X','Firefox','2016-12-16',2),(52,'Mac OS X','Firefox','2016-12-23',1),(53,'iOS','Safari','2016-12-25',2),(54,'Mac OS X','Firefox','2016-12-26',4),(55,'Windows','Gecko','2016-12-29',1),(56,'Windows','Gecko','2016-12-30',4),(57,'Mac OS X','Firefox','2017-01-01',1),(58,'Windows','Gecko','2017-01-04',1),(59,'Mac OS X','Firefox','2017-01-05',1),(60,'Windows','Firefox','2017-01-06',1),(61,'Mac OS X','Firefox','2017-01-06',1),(62,'Mac OS X','Firefox','2017-01-07',1),(63,'Mac OS X','Firefox','2017-01-09',1),(64,'Windows','Gecko','2017-01-10',1),(65,'Windows','Gecko','2017-01-11',1),(66,'Windows','Firefox','2017-01-11',1),(67,'Mac OS X','Firefox','2017-01-11',3),(68,'Mac OS X','Firefox','2017-01-13',1),(69,'Windows','Gecko','2017-01-19',1),(70,'Windows','Gecko','2017-01-23',1),(71,'Mac OS X','Firefox','2017-01-23',3),(72,'iOS','Safari','2017-01-29',1),(73,'Windows','Gecko','2017-01-30',1),(74,'Windows','Firefox','2017-01-30',1),(75,'Windows','Firefox','2017-01-31',1),(76,'Windows','Gecko','2017-02-01',2),(77,'Windows','Gecko','2017-02-02',5),(78,'Mac OS X','Firefox','2017-02-02',2),(79,'Windows','Firefox','2017-02-02',1),(80,'Windows','Firefox','2017-02-03',1),(81,'Mac OS X','Firefox','2017-02-04',1),(82,'Mac OS X','Firefox','2017-02-05',8),(83,'Windows','Gecko','2017-02-06',2),(84,'Mac OS X','Firefox','2017-02-06',1),(85,'Windows','Gecko','2017-02-07',3),(86,'Mac OS X','Firefox','2017-02-09',1),(87,'Mac OS X','Firefox','2017-02-12',4),(88,'Mac OS X','Safari','2017-02-12',2),(89,'Mac OS X','Firefox','2017-02-13',1),(90,'Windows','Gecko','2017-02-14',2),(91,'Mac OS X','Firefox','2017-02-14',3),(92,'Mac OS X','Firefox','2017-02-15',1),(93,'Linux','Firefox','2017-02-16',3),(94,'Mac OS X','Firefox','2017-02-18',1),(95,'Windows','Firefox','2017-02-19',1),(96,'Windows','Firefox','2017-02-22',1),(97,'Windows','Firefox','2017-02-26',1),(98,'Mac OS X','Firefox','2017-02-26',2),(99,'Linux','Firefox','2017-03-10',2),(100,'Linux','Firefox','2017-03-14',1),(101,'Mac OS X','Firefox','2017-03-24',1),(102,'Linux','Firefox','2017-04-04',1),(103,'Mac OS X','Firefox','2017-04-04',1),(104,'Linux','Firefox','2017-04-06',2),(105,'Linux','Firefox','2017-04-11',1),(106,'Mac OS X','Firefox','2017-04-11',1),(107,'Linux','Firefox','2017-06-08',1),(108,'Mac OS X','Firefox','2017-06-09',1),(109,'Linux','Firefox','2017-06-27',1),(110,'Mac OS X','Firefox','2017-07-03',1),(111,'Linux','Firefox','2017-07-05',1),(112,'Mac OS X','Firefox','2017-07-13',1),(113,'Linux','Firefox','2017-07-13',1),(114,'Mac OS X','Firefox','2017-07-14',2),(115,'Linux','Firefox','2017-07-18',4),(116,'Linux','Chrome','2017-07-18',3),(117,'Linux','Firefox','2017-08-09',1),(118,'Linux','Firefox','2017-08-15',1),(119,'Windows','Firefox','2017-08-19',2),(120,'Mac OS X','Firefox','2017-08-19',7),(121,'iOS','Safari','2017-08-19',1),(122,'Mac OS X','Safari','2017-08-19',1),(123,'Mac OS X','Chrome','2017-08-19',1),(124,'Windows','Chrome','2017-08-19',1),(125,'Windows','Firefox','2017-08-20',1),(126,'Mac OS X','Firefox','2017-08-20',8),(127,'iOS','Safari','2017-08-20',2),(128,'Linux','Firefox','2017-08-21',4),(129,'iOS','Safari','2017-08-21',1),(130,'Linux','Firefox','2017-08-22',5),(131,'Mac OS X','Firefox','2017-08-22',2),(132,'Mac OS X','Firefox','2017-08-23',1),(133,'Windows','Firefox','2017-08-24',1),(134,'Mac OS X','Firefox','2017-08-26',1),(135,'Windows','Firefox','2017-08-28',2),(136,'Linux','Firefox','2017-08-28',1),(137,'Windows','Firefox','2017-09-02',2),(138,'Linux','Firefox','2017-09-05',3),(139,'Mac OS X','Firefox','2017-09-05',2),(140,'Linux','Firefox','2017-09-12',2),(141,'Linux','Firefox','2017-09-13',1),(142,'Mac OS X','Firefox','2017-09-13',1),(143,'Windows','Firefox','2017-09-14',1),(144,'Mac OS X','Chrome','2017-09-15',1),(145,'Windows','Firefox','2017-09-18',1),(146,'Mac OS X','Firefox','2017-09-24',2),(147,'Mac OS X','Firefox','2017-09-29',1),(148,'Windows','Firefox','2017-09-29',1),(149,'Mac OS X','Firefox','2017-09-30',1),(150,'Linux','Firefox','2017-10-05',2),(151,'Mac OS X','Firefox','2017-10-10',1),(152,'Mac OS X','Firefox','2017-10-12',1),(153,'Linux','Firefox','2017-10-18',2),(154,'Windows','Firefox','2017-11-08',1),(155,'Mac OS X','Firefox','2017-11-09',1),(156,'Mac OS X','Firefox','2017-11-13',1),(157,'Windows','Firefox','2017-11-16',1),(158,'Linux','Firefox','2017-11-20',2),(159,'Mac OS X','Firefox','2017-11-20',2),(160,'Mac OS X','Firefox','2017-11-21',2),(161,'Linux','Firefox','2017-11-22',3),(162,'Mac OS X','Firefox','2017-11-24',5),(163,'Mac OS X','Firefox','2017-11-25',1),(164,'Linux','Firefox','2017-11-27',1),(165,'Mac OS X','Firefox','2017-11-28',2),(166,'Mac OS X','Firefox','2017-12-09',1),(167,'Mac OS X','Firefox','2017-12-21',1),(168,'Mac OS X','Firefox','2017-12-30',2),(169,'Linux','Firefox','2018-01-18',4),(170,'Linux','Chrome','2018-01-18',1),(171,'Windows','Firefox','2018-01-18',1),(172,'Linux','Firefox','2018-01-22',1),(173,'Mac OS X','Firefox','2018-01-22',2),(174,'Linux','Firefox','2018-01-24',1),(175,'Windows','Firefox','2018-01-24',1),(176,'Mac OS X','Firefox','2018-01-26',5),(177,'Linux','Firefox','2018-01-29',1),(178,'iOS','Safari','2018-01-29',1),(179,'Mac OS X','Firefox','2018-02-01',1),(180,'Windows','Chrome','2018-02-05',2),(181,'Windows','Firefox','2018-02-10',1),(182,'Linux','Firefox','2018-02-12',1),(183,'Windows','Firefox','2018-02-13',1),(184,'Mac OS X','Firefox','2018-02-18',1),(185,'Mac OS X','Firefox','2018-02-24',1),(186,'Windows','Firefox','2018-02-25',1),(187,'Windows','Firefox','2018-02-26',2),(188,'Windows','Firefox','2018-02-28',1),(189,'Linux','Firefox','2018-02-28',1),(190,'Mac OS X','Firefox','2018-02-28',1),(191,'Mac OS X','Firefox','2018-03-04',1),(192,'Mac OS X','Firefox','2018-03-06',1),(193,'Windows','Firefox','2018-03-09',1),(194,'iOS','Safari','2018-03-13',1),(195,'Mac OS X','Firefox','2018-03-14',2),(196,'Windows','Firefox','2018-03-23',1),(197,'Mac OS X','Firefox','2018-03-23',7),(198,'Windows','Firefox','2018-03-24',2),(199,'Mac OS X','Firefox','2018-03-24',2),(200,'Linux','Firefox','2018-03-26',4),(201,'Mac OS X','Firefox','2018-03-26',1),(202,'iOS','Safari','2018-03-26',1),(203,'Linux','Firefox','2018-03-27',2),(204,'Windows','Firefox','2018-03-29',1),(205,'Mac OS X','Firefox','2018-03-31',3),(206,'Linux','Firefox','2018-04-04',7),(207,'Windows','Firefox','2018-04-04',1),(208,'Mac OS X','Firefox','2018-04-04',1),(209,'Mac OS X','Firefox','2018-04-05',1),(210,'Mac OS X','Firefox','2018-04-07',2),(211,'Mac OS X','Firefox','2018-04-10',1),(212,'Linux','Firefox','2018-04-10',2),(213,'iOS','Safari','2018-04-11',1),(214,'Linux','Firefox','2018-04-11',2);
/*!40000 ALTER TABLE `log_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_page_views`
--

DROP TABLE IF EXISTS `log_page_views`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_page_views` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page` tinytext NOT NULL,
  `date` date NOT NULL,
  `count` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_page_views`
--

LOCK TABLES `log_page_views` WRITE;
/*!40000 ALTER TABLE `log_page_views` DISABLE KEYS */;
INSERT INTO `log_page_views` VALUES (1,'homepage','2016-09-19',2),(2,'homepage','2016-09-20',2),(3,'modules','2016-09-20',3),(4,'agenda','2016-09-20',1),(5,'contact','2016-09-20',1),(6,'banshee/login','2016-09-20',3),(7,'homepage','2016-09-21',2),(8,'demos','2016-09-21',7),(9,'demos/graph','2016-09-21',2),(10,'demos/posting','2016-09-21',1),(11,'demos/validation','2016-09-21',7),(12,'demos/splitform','2016-09-21',2),(13,'demos/utf8','2016-09-21',1),(14,'demos/help','2016-09-21',1),(15,'modules','2016-09-21',3),(16,'photo','2016-09-21',18),(17,'webshop','2016-09-21',6),(18,'banshee/login','2016-09-21',2),(19,'homepage','2016-09-22',2),(20,'modules','2016-09-22',3),(21,'photo','2016-09-22',18),(22,'newsletter','2016-09-22',1),(23,'demos','2016-09-22',3),(24,'demos/graph','2016-09-22',1),(25,'banshee/login','2016-09-22',2),(26,'homepage','2016-09-23',1),(27,'modules','2016-09-23',3),(28,'contact','2016-09-23',2),(29,'banshee/login','2016-09-23',2),(30,'search','2016-09-23',2),(31,'homepage','2016-09-24',3),(32,'demos','2016-09-24',3),(33,'demos/googlemaps','2016-09-24',2),(34,'modules','2016-09-24',2),(35,'banshee/login','2016-09-24',1),(36,'register','2016-09-24',1),(37,'homepage','2016-09-26',1),(38,'homepage','2016-09-27',2),(39,'homepage','2016-09-28',2),(40,'banshee/login','2016-09-28',2),(41,'homepage','2016-09-29',16),(42,'banshee/login','2016-09-29',14),(43,'register','2016-09-29',45),(44,'modules','2016-09-29',16),(45,'logout','2016-09-29',2),(46,'password','2016-09-29',5),(47,'agenda','2016-09-29',1),(48,'contact','2016-09-29',1),(49,'demos','2016-09-29',3),(50,'demos/captcha','2016-09-29',1),(51,'captcha','2016-09-29',1),(52,'demos/posting','2016-09-29',1),(53,'faq','2016-09-29',1),(54,'dictionary','2016-09-29',3),(55,'links','2016-09-29',1),(56,'newsletter','2016-09-29',1),(57,'photo','2016-09-29',5),(58,'search','2016-09-29',2),(59,'weblog','2016-09-29',5),(60,'webshop','2016-09-29',1),(61,'homepage','2016-09-30',6),(62,'modules','2016-09-30',3),(63,'demos','2016-09-30',2),(64,'homepage','2016-10-01',40),(65,'homepage','2016-10-04',10),(66,'demos','2016-10-04',2),(67,'demos/errors','2016-10-04',7),(68,'homepage','2016-10-10',11),(69,'modules','2016-10-10',2),(70,'banshee/login','2016-10-10',4),(71,'demos','2016-10-10',1),(72,'demos/graph','2016-10-10',1),(73,'homepage','2016-10-11',12),(74,'demos','2016-10-11',16),(75,'demos/graph','2016-10-11',13),(76,'banshee/login','2016-10-11',18),(77,'demos/pdf','2016-10-11',62),(78,'demos/errors','2016-10-11',240),(79,'modules','2016-10-11',4),(80,'demos/googlemaps','2016-10-11',4),(81,'photo','2016-10-11',5),(82,'demos/pagination','2016-10-11',52),(83,'homepage','2016-10-12',6),(84,'demos','2016-10-12',12),(85,'demos/errors','2016-10-12',3),(86,'modules','2016-10-12',5),(87,'demos/alphabetize','2016-10-12',4),(88,'demos/posting','2016-10-12',4),(89,'demos/graph','2016-10-12',2),(90,'photo','2016-10-12',13),(91,'banshee/login','2016-10-12',4),(92,'register','2016-10-12',1),(93,'password','2016-10-12',1),(94,'homepage','2016-10-17',4),(95,'modules','2016-10-17',1),(96,'photo','2016-10-17',2),(97,'banshee/login','2016-10-17',7),(98,'demos/errors','2016-10-17',16),(99,'homepage','2016-10-18',12),(100,'demos','2016-10-18',4),(101,'demos/pdf','2016-10-18',2),(102,'banshee/login','2016-10-18',3),(103,'demos/errors','2016-10-18',1),(104,'modules','2016-10-18',1),(105,'homepage','2016-10-19',25),(106,'demos','2016-10-19',2),(107,'modules','2016-10-19',3),(108,'banshee/login','2016-10-19',1),(109,'homepage','2016-10-22',10),(110,'banshee/login','2016-10-22',7),(111,'modules','2016-10-22',3),(112,'demos','2016-10-22',4),(113,'setup','2016-10-26',17),(114,'homepage','2016-10-26',3),(115,'agenda','2016-10-26',4),(116,'modules','2016-10-26',1),(117,'forum','2016-10-26',6),(118,'banshee/login','2016-10-31',2),(119,'weblog','2016-11-02',3),(120,'homepage','2016-11-13',2),(121,'demos','2016-11-13',2),(122,'modules','2016-11-13',1),(123,'webshop','2016-11-13',2),(124,'webshop/cart','2016-11-13',2),(125,'banshee/login','2016-11-13',1),(126,'demos/googlemaps','2016-11-13',2),(127,'homepage','2016-11-16',66),(128,'demos','2016-11-16',5),(129,'demos/graph','2016-11-16',2),(130,'modules','2016-11-16',15),(131,'agenda','2016-11-16',2),(132,'contact','2016-11-16',4),(133,'dictionary','2016-11-16',2),(134,'faq','2016-11-16',2),(135,'links','2016-11-16',2),(136,'banshee/login','2016-11-16',22),(137,'logout','2016-11-16',1),(138,'webshop','2016-11-16',1),(139,'password','2016-11-16',1),(140,'register','2016-11-16',2),(141,'demos/errors','2016-11-16',1),(142,'demos/pdf','2016-11-16',8),(143,'demos/googlemaps','2016-11-16',3),(144,'homepage','2016-11-17',42),(145,'demos','2016-11-17',2),(146,'demos/pdf','2016-11-17',10),(147,'modules','2016-11-17',1),(148,'banshee/login','2016-11-17',1),(149,'homepage','2016-11-18',1),(150,'demos/googlemaps','2016-11-20',1),(151,'homepage','2016-11-20',1),(152,'setup','2016-11-21',22),(153,'homepage','2016-11-21',4),(154,'banshee/login','2016-11-21',4),(155,'homepage','2016-11-23',1),(156,'homepage','2016-11-24',3),(157,'modules','2016-11-24',13),(158,'agenda','2016-11-24',7),(159,'contact','2016-11-24',13),(160,'faq','2016-11-24',1),(161,'forum','2016-11-24',4),(162,'guestbook','2016-11-24',2),(163,'links','2016-11-24',1),(164,'banshee/login','2016-11-24',2),(165,'banshee/login','2016-11-25',2),(166,'demos/pdf','2016-11-27',10),(167,'banshee/error','2016-11-27',3),(168,'demos/help','2016-11-27',106),(169,'demos','2016-11-27',2),(170,'demos/graph','2016-11-27',3),(171,'homepage','2016-11-27',8),(172,'modules','2016-11-27',1),(173,'demos/errors','2016-11-27',14),(174,'banshee/login','2016-11-27',2),(175,'setup','2016-11-28',5),(176,'homepage','2016-11-28',4),(177,'homepage','2016-11-30',2),(178,'banshee/error','2016-12-01',1),(179,'demos/pdf','2016-12-02',9),(180,'homepage','2016-12-02',3),(181,'demos','2016-12-02',1),(182,'modules','2016-12-02',1),(183,'homepage','2016-12-03',4),(184,'modules','2016-12-03',3),(185,'contact','2016-12-03',1),(186,'demos','2016-12-03',5),(187,'demos/captcha','2016-12-03',4),(188,'captcha','2016-12-03',7),(189,'banshee/error','2016-12-03',2),(190,'demos/pdf','2016-12-03',3),(191,'news','2016-12-03',2),(192,'guestbook','2016-12-03',1),(193,'demos/errors','2016-12-03',1),(194,'banshee/login','2016-12-03',2),(195,'homepage','2016-12-06',1),(196,'homepage','2016-12-13',5),(197,'banshee/login','2016-12-13',10),(198,'demos','2016-12-13',1),(199,'homepage','2016-12-16',1),(200,'modules','2016-12-16',1),(201,'banshee/login','2016-12-16',1),(202,'homepage','2016-12-23',1),(203,'banshee/login','2016-12-23',2),(204,'homepage','2016-12-25',1),(205,'banshee/login','2016-12-25',2),(206,'logout','2016-12-25',1),(207,'homepage','2016-12-26',4),(208,'banshee/login','2016-12-26',6),(209,'modules','2016-12-26',1),(210,'webshop','2016-12-26',4),(211,'homepage','2016-12-29',2),(212,'banshee/login','2016-12-29',1),(213,'password','2016-12-29',1),(214,'homepage','2016-12-30',31),(215,'banshee/login','2016-12-30',61),(216,'register','2016-12-30',14),(217,'demos','2016-12-30',19),(218,'password','2016-12-30',15),(219,'modules','2016-12-30',11),(220,'banshee/error','2016-12-30',4),(221,'homepage','2017-01-01',1),(222,'homepage','2017-01-04',16),(223,'banshee/login','2017-01-04',9),(224,'register','2017-01-04',23),(225,'homepage','2017-01-05',11),(226,'modules','2017-01-05',3),(227,'demos','2017-01-05',5),(228,'banshee/login','2017-01-05',5),(229,'homepage','2017-01-06',2),(230,'demos','2017-01-06',2),(231,'demos/captcha','2017-01-06',7),(232,'captcha','2017-01-06',9),(233,'demos/googlemaps','2017-01-06',3),(234,'homepage','2017-01-07',2),(235,'demos','2017-01-07',2),(236,'demos/googlemaps','2017-01-07',5),(237,'homepage','2017-01-09',7),(238,'homepage','2017-01-10',1),(239,'banshee/login','2017-01-10',3),(240,'banshee/login','2017-01-11',9),(241,'homepage','2017-01-11',2),(242,'modules','2017-01-11',2),(243,'links','2017-01-11',20),(244,'demos','2017-01-13',1),(245,'search','2017-01-19',4),(246,'homepage','2017-01-19',1),(247,'homepage','2017-01-23',4),(248,'banshee/login','2017-01-23',5),(249,'contact','2017-01-23',1),(250,'photo','2017-01-23',33),(251,'modules','2017-01-23',2),(252,'demos','2017-01-23',1),(253,'homepage','2017-01-29',1),(254,'banshee/login','2017-01-29',2),(255,'homepage','2017-01-30',6),(256,'banshee/login','2017-01-30',8),(257,'banshee/login','2017-01-31',2),(258,'homepage','2017-02-01',2),(259,'modules','2017-02-01',1),(260,'demos','2017-02-01',1),(261,'demos/googlemaps','2017-02-01',4),(262,'homepage','2017-02-02',30),(263,'demos','2017-02-02',20),(264,'banshee/login','2017-02-02',59),(265,'contact','2017-02-02',26),(266,'modules','2017-02-02',13),(267,'logout','2017-02-02',1),(268,'password','2017-02-02',9),(269,'banshee/error','2017-02-02',6),(270,'register','2017-02-02',6),(271,'demos/graph','2017-02-02',1),(272,'demos/posting','2017-02-02',5),(273,'demos/alphabetize','2017-02-02',1),(274,'photo','2017-02-02',9),(275,'demos/pdf','2017-02-02',1),(276,'search','2017-02-02',2),(277,'demos/splitform','2017-02-02',1),(278,'demos/utf8','2017-02-02',1),(279,'demos/googlemaps','2017-02-02',2),(280,'agenda','2017-02-02',1),(281,'homepage','2017-02-03',2),(282,'banshee/login','2017-02-03',4),(283,'homepage','2017-02-04',3),(284,'modules','2017-02-04',1),(285,'contact','2017-02-04',1),(286,'homepage','2017-02-05',27),(287,'banshee/login','2017-02-05',22),(288,'contact','2017-02-05',27),(289,'banshee/error','2017-02-05',1),(290,'demos/api','2017-02-05',46),(291,'modules','2017-02-05',9),(292,'demos','2017-02-05',5),(293,'homepage','2017-02-06',10),(294,'demos','2017-02-06',3),(295,'modules','2017-02-06',3),(296,'contact','2017-02-06',2),(297,'banshee/login','2017-02-06',5),(298,'homepage','2017-02-07',1),(299,'banshee/login','2017-02-07',4),(300,'homepage','2017-02-09',1),(301,'homepage','2017-02-12',13),(302,'banshee/login','2017-02-12',22),(303,'cms/user','2017-02-12',27),(304,'banshee/error','2017-02-12',14),(305,'logout','2017-02-12',4),(306,'demos','2017-02-12',1),(307,'modules','2017-02-12',1),(308,'search','2017-02-12',2),(309,'homepage','2017-02-13',26),(310,'banshee/login','2017-02-13',16),(311,'logout','2017-02-13',1),(312,'banshee/login','2017-02-14',17),(313,'homepage','2017-02-14',9),(314,'modules','2017-02-14',12),(315,'demos','2017-02-14',6),(316,'newsletter','2017-02-14',1),(317,'forum','2017-02-14',1),(318,'photo','2017-02-14',32),(319,'search','2017-02-14',1),(320,'news','2017-02-14',1),(321,'demos/googlemaps','2017-02-14',2),(322,'password','2017-02-14',2),(323,'register','2017-02-14',1),(324,'logout','2017-02-14',1),(325,'homepage','2017-02-15',1),(326,'banshee/login','2017-02-15',2),(327,'contact','2017-02-16',259),(328,'homepage','2017-02-16',6),(329,'homepage','2017-02-18',4),(330,'modules','2017-02-18',1),(331,'demos','2017-02-18',1),(332,'demos/googlemaps','2017-02-18',2),(333,'banshee/login','2017-02-18',2),(334,'homepage','2017-02-19',1),(335,'modules','2017-02-19',2),(336,'demos','2017-02-19',1),(337,'homepage','2017-02-22',1),(338,'demos','2017-02-22',2),(339,'modules','2017-02-22',1),(340,'banshee/login','2017-02-22',3),(341,'banshee/login','2017-02-26',9),(342,'homepage','2017-02-26',3),(343,'homepage','2017-03-10',11),(344,'banshee/login','2017-03-10',40),(345,'logout','2017-03-10',1),(346,'homepage','2017-03-14',1),(347,'banshee/login','2017-03-14',2),(348,'homepage','2017-03-24',1),(349,'banshee/login','2017-03-24',2),(350,'homepage','2017-04-04',8),(351,'demos','2017-04-06',1),(352,'demos/errors','2017-04-06',1),(353,'homepage','2017-04-06',1),(354,'homepage','2017-04-11',3),(355,'banshee/login','2017-04-11',6),(356,'homepage','2017-06-08',1),(357,'modules','2017-06-08',2),(358,'webshop','2017-06-08',4),(359,'demos','2017-06-08',1),(360,'weblog','2017-06-08',4),(361,'banshee/login','2017-06-08',2),(362,'homepage','2017-06-09',1),(363,'demos','2017-06-09',1),(364,'demos/graph','2017-06-09',1),(365,'homepage','2017-06-27',1),(366,'banshee/login','2017-06-27',2),(367,'homepage','2017-07-03',1),(368,'banshee/login','2017-07-03',3),(369,'homepage','2017-07-05',1),(370,'homepage','2017-07-13',4),(371,'modules','2017-07-13',5),(372,'demos','2017-07-13',1),(373,'demos/ckeditor','2017-07-13',1),(374,'agenda','2017-07-13',2),(375,'banshee/login','2017-07-13',7),(376,'webshop','2017-07-13',12),(377,'webshop/cart','2017-07-13',3),(378,'homepage','2017-07-14',1),(379,'demos/ckeditor','2017-07-14',1),(380,'homepage','2017-07-18',27),(381,'banshee/login','2017-07-18',2),(382,'banshee/error','2017-07-18',2),(383,'homepage','2017-08-09',2),(384,'homepage','2017-08-15',1),(385,'webshop','2017-08-15',1),(386,'weblog','2017-08-15',7),(387,'demos','2017-08-15',1),(388,'banshee/login','2017-08-15',2),(389,'homepage','2017-08-19',5),(390,'banshee/login','2017-08-19',27),(391,'banshee/error','2017-08-19',5),(392,'modules','2017-08-19',1),(393,'demos','2017-08-19',1),(394,'homepage','2017-08-20',18),(395,'banshee/login','2017-08-20',51),(396,'logout','2017-08-20',3),(397,'news','2017-08-20',10),(398,'modules','2017-08-20',1),(399,'cms/weblog','2017-08-20',2),(400,'cms/weblog/comment','2017-08-20',33),(401,'homepage','2017-08-21',7),(402,'banshee/login','2017-08-21',19),(403,'logout','2017-08-21',1),(404,'banshee/error','2017-08-21',1),(405,'demos','2017-08-21',2),(406,'modules','2017-08-21',14),(407,'agenda','2017-08-21',1),(408,'contact','2017-08-21',1),(409,'dictionary','2017-08-21',4),(410,'faq','2017-08-21',1),(411,'forum','2017-08-21',3),(412,'guestbook','2017-08-21',1),(413,'links','2017-08-21',2),(414,'weblog','2017-08-21',5),(415,'webshop','2017-08-21',10),(416,'webshop/cart','2017-08-21',3),(417,'photo','2017-08-21',11),(418,'homepage','2017-08-22',4),(419,'modules','2017-08-22',7),(420,'banshee/login','2017-08-22',13),(421,'demos','2017-08-22',1),(422,'demos/googlemaps','2017-08-22',2),(423,'agenda','2017-08-22',1),(424,'contact','2017-08-22',3),(425,'guestbook','2017-08-22',2),(426,'news','2017-08-22',4),(427,'homepage','2017-08-23',1),(428,'banshee/login','2017-08-23',5),(429,'homepage','2017-08-24',2),(430,'demos','2017-08-24',4),(431,'modules','2017-08-24',5),(432,'weblog','2017-08-24',1),(433,'webshop','2017-08-24',5),(434,'photo','2017-08-24',9),(435,'homepage','2017-08-26',3),(436,'modules','2017-08-26',2),(437,'webshop','2017-08-26',1),(438,'demos','2017-08-26',7),(439,'demos/ckeditor','2017-08-26',1),(440,'demos/googlemaps','2017-08-26',8),(441,'demos/graph','2017-08-26',1),(442,'banshee/login','2017-08-26',4),(443,'demos/splitform','2017-08-26',2),(444,'demos/utf8','2017-08-26',1),(445,'demos/help','2017-08-26',1),(446,'homepage','2017-08-28',4),(447,'modules','2017-08-28',1),(448,'demos','2017-08-28',2),(449,'banshee/login','2017-08-28',2),(450,'webshop','2017-09-02',1),(451,'photo','2017-09-02',1),(452,'homepage','2017-09-05',4),(453,'banshee/login','2017-09-05',7),(454,'demos','2017-09-05',2),(455,'modules','2017-09-05',2),(456,'webshop','2017-09-05',4),(457,'homepage','2017-09-12',2),(458,'banshee/login','2017-09-13',4),(459,'homepage','2017-09-14',1),(460,'demos','2017-09-14',1),(461,'banshee/login','2017-09-14',2),(462,'banshee/login','2017-09-15',1),(463,'homepage','2017-09-18',1),(464,'news','2017-09-24',1),(465,'homepage','2017-09-24',2),(466,'photo','2017-09-24',15),(467,'modules','2017-09-24',1),(468,'homepage','2017-09-29',2),(469,'banshee/login','2017-09-30',4),(470,'homepage','2017-09-30',1),(471,'banshee/error','2017-10-05',2),(472,'banshee/login','2017-10-05',5),(473,'homepage','2017-10-10',4),(474,'banshee/login','2017-10-10',2),(475,'homepage','2017-10-12',4),(476,'homepage','2017-10-18',4),(477,'banshee/login','2017-10-18',3),(478,'homepage','2017-11-08',2),(479,'demos','2017-11-09',1),(480,'demos/captcha','2017-11-09',3),(481,'captcha','2017-11-09',3),(482,'demos/splitform','2017-11-09',1),(483,'homepage','2017-11-13',1),(484,'homepage','2017-11-16',3),(485,'demos','2017-11-16',1),(486,'demos/googlemaps','2017-11-16',5),(487,'modules','2017-11-16',2),(488,'weblog','2017-11-16',2),(489,'news','2017-11-16',2),(490,'homepage','2017-11-20',2),(491,'banshee/login','2017-11-20',8),(492,'homepage','2017-11-21',1),(493,'banshee/login','2017-11-21',2),(494,'search','2017-11-21',1),(495,'homepage','2017-11-22',1),(496,'banshee/login','2017-11-22',7),(497,'homepage','2017-11-24',4),(498,'modules','2017-11-24',2),(499,'demos','2017-11-24',2),(500,'demos/googlemaps','2017-11-24',2),(501,'homepage','2017-11-25',2),(502,'homepage','2017-11-27',2),(503,'modules','2017-11-27',4),(504,'demos','2017-11-27',2),(505,'banshee/login','2017-11-27',1),(506,'homepage','2017-11-28',2),(507,'banshee/login','2017-11-28',4),(508,'homepage','2017-12-09',80),(509,'modules','2017-12-09',6),(510,'demos','2017-12-09',3),(511,'banshee/login','2017-12-09',8),(512,'banshee/login','2017-12-21',3),(513,'homepage','2017-12-30',3),(514,'banshee/login','2017-12-30',5),(515,'banshee/error','2017-12-30',1),(516,'modules','2017-12-30',1),(517,'dictionary','2017-12-30',6),(518,'homepage','2018-01-18',10),(519,'modules','2018-01-18',6),(520,'demos','2018-01-18',3),(521,'demos/help','2018-01-18',1),(522,'webshop','2018-01-18',31),(523,'banshee/login','2018-01-18',5),(524,'logout','2018-01-18',1),(525,'homepage','2018-01-22',23),(526,'register','2018-01-22',9),(527,'banshee/login','2018-01-24',5),(528,'homepage','2018-01-26',1),(529,'banshee/login','2018-01-26',10),(530,'forum','2018-01-26',3),(531,'banshee/login','2018-01-29',2),(532,'homepage','2018-01-29',2),(533,'modules','2018-01-29',1),(534,'demos','2018-01-29',2),(535,'demos/googlemaps','2018-01-29',2),(536,'homepage','2018-02-01',1),(537,'homepage','2018-02-05',1),(538,'banshee/login','2018-02-05',5),(539,'search','2018-02-10',2),(540,'homepage','2018-02-12',1),(541,'banshee/login','2018-02-12',2),(542,'homepage','2018-02-13',1),(543,'search','2018-02-13',3),(544,'homepage','2018-02-18',1),(545,'homepage','2018-02-24',1),(546,'banshee/login','2018-02-24',3),(547,'homepage','2018-02-25',1),(548,'modules','2018-02-25',1),(549,'forum','2018-02-25',1),(550,'banshee/login','2018-02-25',2),(551,'homepage','2018-02-26',1),(552,'demos','2018-02-26',1),(553,'banshee/login','2018-02-26',2),(554,'links','2018-02-26',1),(555,'homepage','2018-02-28',2),(556,'modules','2018-02-28',16),(557,'demos','2018-02-28',1),(558,'weblog','2018-02-28',1),(559,'webshop','2018-02-28',15),(560,'forum','2018-02-28',2),(561,'banshee/login','2018-02-28',5),(562,'agenda','2018-02-28',1),(563,'contact','2018-02-28',1),(564,'faq','2018-02-28',1),(565,'links','2018-02-28',1),(566,'news','2018-02-28',2),(567,'newsletter','2018-02-28',1),(568,'photo','2018-02-28',9),(569,'poll','2018-02-28',1),(570,'homepage','2018-03-04',2),(571,'banshee/login','2018-03-04',1),(572,'modules','2018-03-04',1),(573,'weblog','2018-03-04',3),(574,'homepage','2018-03-06',51),(575,'modules','2018-03-06',1),(576,'agenda','2018-03-06',1),(577,'photo','2018-03-06',8),(578,'banshee/login','2018-03-06',2),(579,'homepage','2018-03-09',1),(580,'modules','2018-03-09',2),(581,'forum','2018-03-09',7),(582,'homepage','2018-03-13',1),(583,'demos','2018-03-13',1),(584,'demos/graph','2018-03-13',1),(585,'homepage','2018-03-14',1),(586,'banshee/login','2018-03-14',2),(587,'forum','2018-03-14',5),(588,'homepage','2018-03-23',21),(589,'banshee/login','2018-03-23',27),(590,'modules','2018-03-23',2),(591,'demos','2018-03-23',6),(592,'demos/posting','2018-03-23',11),(593,'homepage','2018-03-24',4),(594,'banshee/login','2018-03-24',6),(595,'demos','2018-03-24',1),(596,'logout','2018-03-24',1),(597,'homepage','2018-03-26',19),(598,'banshee/login','2018-03-26',4),(599,'banshee/error','2018-03-26',9),(600,'logout','2018-03-26',1),(601,'modules','2018-03-26',2),(602,'agenda','2018-03-26',4),(603,'register','2018-03-27',2),(604,'banshee/login','2018-03-29',2),(605,'homepage','2018-03-31',1),(606,'banshee/login','2018-03-31',4),(607,'demos','2018-03-31',1),(608,'photo','2018-03-31',13),(609,'homepage','2018-04-04',10),(610,'banshee/login','2018-04-04',15),(611,'demos/language','2018-04-04',14),(612,'demos','2018-04-04',3),(613,'modules','2018-04-04',5),(614,'agenda','2018-04-04',1),(615,'news','2018-04-04',1),(616,'links','2018-04-04',1),(617,'weblog','2018-04-04',1),(618,'homepage','2018-04-05',1),(619,'demos','2018-04-05',1),(620,'demos/language','2018-04-05',1),(621,'banshee/login','2018-04-05',3),(622,'demos','2018-04-07',1),(623,'demos/language','2018-04-07',3),(624,'homepage','2018-04-07',1),(625,'banshee/login','2018-04-07',1),(626,'homepage','2018-04-10',3),(627,'modules','2018-04-10',2),(628,'photo','2018-04-10',8),(629,'forum','2018-04-10',3),(630,'banshee/login','2018-04-10',4),(631,'logout','2018-04-10',1),(632,'homepage','2018-04-11',13),(633,'banshee/login','2018-04-11',14),(634,'profile','2018-04-11',9),(635,'logout','2018-04-11',1),(636,'register','2018-04-11',6),(637,'banshee/error','2018-04-11',1);
/*!40000 ALTER TABLE `log_page_views` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_referers`
--

DROP TABLE IF EXISTS `log_referers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_referers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hostname` tinytext NOT NULL,
  `url` text NOT NULL,
  `date` date NOT NULL,
  `count` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_referers`
--

LOCK TABLES `log_referers` WRITE;
/*!40000 ALTER TABLE `log_referers` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_referers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_search_queries`
--

DROP TABLE IF EXISTS `log_search_queries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_search_queries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `query` tinytext NOT NULL,
  `date` date NOT NULL,
  `count` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_search_queries`
--

LOCK TABLES `log_search_queries` WRITE;
/*!40000 ALTER TABLE `log_search_queries` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_search_queries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_visits`
--

DROP TABLE IF EXISTS `log_visits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_visits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `count` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_visits`
--

LOCK TABLES `log_visits` WRITE;
/*!40000 ALTER TABLE `log_visits` DISABLE KEYS */;
INSERT INTO `log_visits` VALUES (1,'2016-09-19',1),(2,'2016-09-20',1),(3,'2016-09-21',1),(4,'2016-09-22',1),(5,'2016-09-23',1),(6,'2016-09-24',1),(7,'2016-09-26',1),(8,'2016-09-27',2),(9,'2016-09-28',2),(10,'2016-09-29',4),(11,'2016-09-30',2),(12,'2016-10-01',4),(13,'2016-10-04',1),(14,'2016-10-10',3),(15,'2016-10-11',169),(16,'2016-10-12',1),(17,'2016-10-17',5),(18,'2016-10-18',2),(19,'2016-10-19',2),(20,'2016-10-22',3),(21,'2016-10-26',2),(22,'2016-10-31',1),(23,'2016-11-02',1),(24,'2016-11-13',2),(25,'2016-11-16',4),(26,'2016-11-17',7),(27,'2016-11-18',1),(28,'2016-11-20',2),(29,'2016-11-21',2),(30,'2016-11-23',1),(31,'2016-11-24',2),(32,'2016-11-25',1),(33,'2016-11-27',2),(34,'2016-11-28',3),(35,'2016-11-30',2),(36,'2016-12-01',1),(37,'2016-12-02',2),(38,'2016-12-03',3),(39,'2016-12-06',1),(40,'2016-12-13',3),(41,'2016-12-16',2),(42,'2016-12-23',1),(43,'2016-12-25',2),(44,'2016-12-26',4),(45,'2016-12-29',1),(46,'2016-12-30',4),(47,'2017-01-01',1),(48,'2017-01-04',1),(49,'2017-01-05',1),(50,'2017-01-06',2),(51,'2017-01-07',1),(52,'2017-01-09',1),(53,'2017-01-10',1),(54,'2017-01-11',5),(55,'2017-01-13',1),(56,'2017-01-19',1),(57,'2017-01-23',4),(58,'2017-01-29',1),(59,'2017-01-30',2),(60,'2017-01-31',1),(61,'2017-02-01',2),(62,'2017-02-02',8),(63,'2017-02-03',1),(64,'2017-02-04',1),(65,'2017-02-05',8),(66,'2017-02-06',3),(67,'2017-02-07',3),(68,'2017-02-09',1),(69,'2017-02-12',6),(70,'2017-02-13',1),(71,'2017-02-14',5),(72,'2017-02-15',1),(73,'2017-02-16',3),(74,'2017-02-18',1),(75,'2017-02-19',1),(76,'2017-02-22',1),(77,'2017-02-26',3),(78,'2017-03-10',2),(79,'2017-03-14',1),(80,'2017-03-24',1),(81,'2017-04-04',2),(82,'2017-04-06',2),(83,'2017-04-11',2),(84,'2017-06-08',1),(85,'2017-06-09',1),(86,'2017-06-27',1),(87,'2017-07-03',1),(88,'2017-07-05',1),(89,'2017-07-13',2),(90,'2017-07-14',2),(91,'2017-07-18',7),(92,'2017-08-09',1),(93,'2017-08-15',1),(94,'2017-08-19',13),(95,'2017-08-20',11),(96,'2017-08-21',5),(97,'2017-08-22',7),(98,'2017-08-23',1),(99,'2017-08-24',1),(100,'2017-08-26',1),(101,'2017-08-28',3),(102,'2017-09-02',2),(103,'2017-09-05',5),(104,'2017-09-12',2),(105,'2017-09-13',2),(106,'2017-09-14',1),(107,'2017-09-15',1),(108,'2017-09-18',1),(109,'2017-09-24',2),(110,'2017-09-29',2),(111,'2017-09-30',1),(112,'2017-10-05',2),(113,'2017-10-10',1),(114,'2017-10-12',1),(115,'2017-10-18',2),(116,'2017-11-08',1),(117,'2017-11-09',1),(118,'2017-11-13',1),(119,'2017-11-16',1),(120,'2017-11-20',4),(121,'2017-11-21',2),(122,'2017-11-22',3),(123,'2017-11-24',5),(124,'2017-11-25',1),(125,'2017-11-27',1),(126,'2017-11-28',2),(127,'2017-12-09',1),(128,'2017-12-21',1),(129,'2017-12-30',2),(130,'2018-01-18',6),(131,'2018-01-22',3),(132,'2018-01-24',2),(133,'2018-01-26',5),(134,'2018-01-29',2),(135,'2018-02-01',1),(136,'2018-02-05',2),(137,'2018-02-10',1),(138,'2018-02-12',1),(139,'2018-02-13',1),(140,'2018-02-18',1),(141,'2018-02-24',1),(142,'2018-02-25',1),(143,'2018-02-26',2),(144,'2018-02-28',3),(145,'2018-03-04',1),(146,'2018-03-06',1),(147,'2018-03-09',1),(148,'2018-03-13',1),(149,'2018-03-14',2),(150,'2018-03-23',8),(151,'2018-03-24',4),(152,'2018-03-26',6),(153,'2018-03-27',2),(154,'2018-03-29',1),(155,'2018-03-31',3),(156,'2018-04-04',9),(157,'2018-04-05',1),(158,'2018-04-07',2),(159,'2018-04-10',3),(160,'2018-04-11',3);
/*!40000 ALTER TABLE `log_visits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mailbox`
--

DROP TABLE IF EXISTS `mailbox`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mailbox` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `from_user_id` int(10) unsigned NOT NULL,
  `to_user_id` int(10) unsigned NOT NULL,
  `subject` tinytext NOT NULL,
  `message` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `read` tinyint(4) NOT NULL DEFAULT '0',
  `deleted_by` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `from_user_id` (`from_user_id`),
  KEY `to_user_id` (`to_user_id`),
  CONSTRAINT `mailbox_ibfk_1` FOREIGN KEY (`from_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `mailbox_ibfk_2` FOREIGN KEY (`to_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mailbox`
--

LOCK TABLES `mailbox` WRITE;
/*!40000 ALTER TABLE `mailbox` DISABLE KEYS */;
/*!40000 ALTER TABLE `mailbox` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL,
  `text` varchar(100) NOT NULL,
  `link` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES (1,0,'Home','/'),(2,0,'Modules','/modules'),(3,0,'Demos','/demos'),(4,3,'Test','/test'),(5,0,'CMS','/cms');
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news`
--

LOCK TABLES `news` WRITE;
/*!40000 ALTER TABLE `news` DISABLE KEYS */;
INSERT INTO `news` VALUES (1,'Lorum ipsum','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean ac elit quam. Nullam aliquam justo et nisi dictum pretium interdum tellus hendrerit. Aenean tristique posuere dictum. Maecenas nec sapien ut magna suscipit euismod quis ut metus. Aenean sit amet metus a turpis iaculis mollis. Nam faucibus mauris vel ligula ultricies dapibus. Nullam quis orci ac sem convallis malesuada nec id nisi. Praesent quis tellus nec sapien viverra blandit at ut erat. Curabitur bibendum malesuada erat, in suscipit leo porta et. Cras quis arcu sit amet nibh molestie mollis eu eget nulla. Vivamus sed enim fringilla elit pretium feugiat. Nullam elementum fermentum nunc in sodales.</p>\r\n\r\n<p>Mauris nec nunc quis enim porttitor consectetur at et lorem. Vivamus ac rutrum sapien. Nullam metus lectus, lobortis sit amet vulputate sit amet, fermentum sed velit. Phasellus ac libero urna. Maecenas tellus massa, ultrices sed pretium non, faucibus ut lorem. Donec aliquam vehicula ante, eu sodales felis ullamcorper at. Sed sed odio ipsum. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nullam laoreet tristique est in molestie. Sed lacinia euismod porttitor. Praesent ullamcorper fringilla arcu sit amet viverra. Aliquam erat volutpat.</p>\r\n\r\n<p>Nulla vel eros quam. Nam nec turpis ac turpis pulvinar facilisis non non nunc. Nam bibendum nunc in velit cursus rutrum. Integer at ultricies orci. Suspendisse vitae sodales dui. Integer malesuada hendrerit dui, a ullamcorper mauris aliquam sit amet. Nulla dignissim tortor accumsan velit laoreet non eleifend massa aliquet. Quisque luctus dapibus viverra. Aliquam sed lorem diam. Phasellus condimentum lectus vitae ipsum molestie a vestibulum risus malesuada. Duis posuere urna a arcu facilisis sit amet blandit lacus tempus. Vestibulum vel arcu nunc, ut imperdiet massa. Donec congue risus nec urna laoreet et euismod magna semper. Fusce pharetra porttitor ultrices.</p>','2017-07-01 00:00:00');
/*!40000 ALTER TABLE `news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organisations`
--

DROP TABLE IF EXISTS `organisations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organisations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `name_2` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organisations`
--

LOCK TABLES `organisations` WRITE;
/*!40000 ALTER TABLE `organisations` DISABLE KEYS */;
INSERT INTO `organisations` VALUES (1,'My organisation');
/*!40000 ALTER TABLE `organisations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_access`
--

DROP TABLE IF EXISTS `page_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page_access` (
  `page_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  `level` int(10) unsigned NOT NULL,
  PRIMARY KEY (`page_id`,`role_id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `page_access_ibfk_1` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`),
  CONSTRAINT `page_access_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_access`
--

LOCK TABLES `page_access` WRITE;
/*!40000 ALTER TABLE `page_access` DISABLE KEYS */;
INSERT INTO `page_access` VALUES (4,2,1);
/*!40000 ALTER TABLE `page_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(100) NOT NULL,
  `language` varchar(2) NOT NULL,
  `layout` varchar(100) DEFAULT NULL,
  `private` tinyint(1) NOT NULL,
  `style` text,
  `title` varchar(100) NOT NULL,
  `description` varchar(200) NOT NULL,
  `keywords` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `visible` tinyint(1) NOT NULL,
  `back` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`,`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,'/homepage','en',NULL,0,'img.logo {\r\n  float:right;\r\n  margin-left:20px;\r\n  width:250px;\r\n}\r\n\r\n@media (max-width:767px) {\r\n  img.logo {\r\n    display:block;\r\n    float:none;\r\n    width:100%;\r\n    max-width:400px;\r\n    margin:10px auto;\r\n  }\r\n}','Welcome to Banshee, the secure PHP framework','','','<p>Banshee is a PHP website framework, which aims at to be secure, fast and easy to use. It uses the Model-View-Control architecture with XSLT for the View. Although it was designed to use MySQL as the database, other database applications can be used as well with only little effort. For more information about Banshee, visit the <a href=\"http://www.banshee-php.org/\">Banshee website</a>.</p>\r\n\r\n<img src=\"https://www.banshee-php.org/logo.php\" class=\"logo\" alt=\"Banshee logo\">\r\n\r\n<p>In this default installation, there are two users available: \'admin\' and \'user\'. Both have the password \'banshee\'.</p>\r\n\r\n<p>If security is a high priority for your website, you should take a look at the <a href=\"http://www.hiawatha-webserver.org/\">Hiawatha webserver</a>.</p>',1,0),(3,'/demos','en',NULL,0,NULL,'Banshee functionality demos','Banshee demos','banshee, demos','<ul>\r\n<li>The <a href=\"/demos/captcha\">captcha</a> library.</li>\r\n<li>This page shows <a href=\"/demos/errors\">errors and messages</a> generated by the framework.</li>\r\n<li>An <a href=\"/demos/invisible\">invisible</a> page, a <a href=\"/demos/private\">private</a> page and a <a href=\"/demos/void\">non-existing</a> page.</li>\r\n<li>The WYSIWYG <a href=\"/demos/ckeditor\">CKEditor</a>.</li>\r\n<li><a href=\"/demos/googlemaps\">GoogleMaps static map</a> demo.</a></li>\r\n<li>A <a href=\"/demos/pagination\">pagination</a> library.</li>\r\n<li>An <a href=\"/demos/alphabetize\">alphabetize</a> library.</li>\r\n<li>A <a href=\"/demos/language\">language-specific page</a> demo.</li>\r\n<li>A <a href=\"/demos/pdf\">PDF</a> library.</li>\r\n<li>A <a href=\"/demos/graph\">graph</a> library.</li>\r\n<li>A <a href=\"/demos/poll\">poll</a> module.</li>\r\n<li>The <a href=\"/demos/posting\">posting</a> library.</li>\r\n<li>The <a href=\"/demos/tablemanager\">tablemanager</a> library.</li>\r\n<li>The <a href=\"/demos/splitform\">splitform</a> library.</li>\r\n<li><a href=\"/demos/utf8\">UTF-8</a> character encoding.</li>\r\n<li>A library for <a href=\"/demos/validation\">input validation</a>.</li>\r\n<li>Page with a <a href=\"/demos/help\">help</a> pop-up.</li>\r\n</ul>',1,0),(4,'/demos/private','en',NULL,1,NULL,'Private page','','','<p>This is a private page.</p>',1,1),(5,'/demos/invisible','en',NULL,0,NULL,'Invisible page','','','<p>This page is invisible to normal users and visitors. Only users with access to the page administration page can view this page.</p>\r\n<p>Page administrators can use this feature to verify a page before making it available to visitors.</p>',0,1),(6,'/demos/utf8','en',NULL,0,NULL,'UTF-8 demo','','','<p>這是一個測試頁，以顯示漢字。</p>',1,1),(179,'/modules','en',NULL,0,NULL,'Banshee modules','Modules in Banshee','modules','<ul>\r\n<li><a href=\"/agenda\">Agenda</a></li>\r\n<li><a href=\"/contact\">Contact form</a></li>\r\n<li><a href=\"/dictionary\">Dictionary</a></li>\r\n<li><a href=\"/faq\">F.A.Q.</a></li>\r\n<li><a href=\"/forum\">Forum</a></li>\r\n<li><a href=\"/guestbook\">Guestbook</a></li>\r\n<li><a href=\"/links\">Links</a></li>\r\n<li><a href=\"/mailbox\">Mailbox</a></li>\r\n<li><a href=\"/news\">News</a></li>\r\n<li><a href=\"/newsletter\">Newsletter</a></li>\r\n<li><a href=\"/photo\">Photo album</a></li>\r\n<li><a href=\"/collection\">Photo album collections</a></li>\r\n<li><a href=\"/poll\">Poll</a></li>\r\n<li><a href=\"/profile\">Profile manager</a></li>\r\n<li><a href=\"/search\">Search</a></li>\r\n<li><a href=\"/session\">Session manager</a></li>\r\n<li><a href=\"/weblog\">Weblog</a></li>\r\n<li><a href=\"/webshop\">Webshop</a></li>\r\n</ul>',1,0),(225,'/demos/language','en',NULL,0,NULL,'Language demo','','','<p>The language in which this page is shown depends on the Accept-Language HTTP header.</p>',1,0),(226,'/demos/language','nl',NULL,0,NULL,'Taal demo','','','<p>De taal waarin deze pagina wordt weergegeven is afhankelijk van de Accept-Language HTTP header.</p>',1,0);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `photo_albums`
--

DROP TABLE IF EXISTS `photo_albums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `photo_albums` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `timestamp` date NOT NULL,
  `listed` tinyint(1) NOT NULL,
  `private` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `photo_albums`
--

LOCK TABLES `photo_albums` WRITE;
/*!40000 ALTER TABLE `photo_albums` DISABLE KEYS */;
INSERT INTO `photo_albums` VALUES (1,'Star Wars wallpapers','Collection of wallpapers from the Star Wars movies.','2010-08-21',1,0);
/*!40000 ALTER TABLE `photo_albums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `photos`
--

DROP TABLE IF EXISTS `photos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `photos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `photo_album_id` int(10) unsigned NOT NULL,
  `extension` varchar(6) NOT NULL,
  `overview` tinyint(1) NOT NULL,
  `thumbnail_mode` tinyint(3) unsigned NOT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `photo_album_id` (`photo_album_id`),
  CONSTRAINT `photos_ibfk_1` FOREIGN KEY (`photo_album_id`) REFERENCES `photo_albums` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `photos`
--

LOCK TABLES `photos` WRITE;
/*!40000 ALTER TABLE `photos` DISABLE KEYS */;
INSERT INTO `photos` VALUES (1,'Snowspeeder',1,'jpg',1,0,0),(2,'Death Star',1,'jpg',0,0,1),(3,'X-Wing',1,'jpg',0,0,2);
/*!40000 ALTER TABLE `photos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poll_answers`
--

DROP TABLE IF EXISTS `poll_answers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `poll_answers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `poll_id` int(11) unsigned NOT NULL,
  `answer` varchar(100) NOT NULL,
  `votes` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `poll_id` (`poll_id`),
  CONSTRAINT `poll_answers_ibfk_1` FOREIGN KEY (`poll_id`) REFERENCES `polls` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `poll_answers`
--

LOCK TABLES `poll_answers` WRITE;
/*!40000 ALTER TABLE `poll_answers` DISABLE KEYS */;
INSERT INTO `poll_answers` VALUES (4,2,'Hiawatha',1),(5,2,'Apache',0),(6,2,'Cherokee',0),(7,2,'Nginx',0),(8,2,'Lighttpd',0),(13,3,'Windows',0),(14,3,'MacOS X',0),(15,3,'Linux',3),(16,3,'BSD',0);
/*!40000 ALTER TABLE `poll_answers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `polls`
--

DROP TABLE IF EXISTS `polls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `polls` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(100) NOT NULL,
  `begin` date DEFAULT NULL,
  `end` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `polls`
--

LOCK TABLES `polls` WRITE;
/*!40000 ALTER TABLE `polls` DISABLE KEYS */;
INSERT INTO `polls` VALUES (2,'The best webserver','2017-01-01','2020-12-31'),(3,'Best OS','2015-05-26','2015-06-28');
/*!40000 ALTER TABLE `polls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reroute`
--

DROP TABLE IF EXISTS `reroute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reroute` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `original` varchar(100) NOT NULL,
  `replacement` varchar(100) NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `description` tinytext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reroute`
--

LOCK TABLES `reroute` WRITE;
/*!40000 ALTER TABLE `reroute` DISABLE KEYS */;
/*!40000 ALTER TABLE `reroute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `non_admins` smallint(6) NOT NULL,
  `profile` tinyint(1) NOT NULL,
  `mailbox` tinyint(1) NOT NULL,
  `session` tinyint(1) NOT NULL,
  `demos/tablemanager` tinyint(1) NOT NULL,
  `cms` tinyint(1) NOT NULL,
  `cms/access` tinyint(1) NOT NULL,
  `cms/action` tinyint(1) NOT NULL,
  `cms/agenda` tinyint(1) NOT NULL,
  `cms/analytics` tinyint(1) NOT NULL,
  `cms/apitest` tinyint(1) NOT NULL,
  `cms/dictionary` tinyint(1) NOT NULL,
  `cms/faq` tinyint(1) NOT NULL,
  `cms/file` tinyint(1) NOT NULL,
  `cms/flag` tinyint(1) NOT NULL,
  `cms/forum` tinyint(1) NOT NULL,
  `cms/forum/section` tinyint(1) NOT NULL,
  `cms/guestbook` tinyint(1) NOT NULL,
  `cms/menu` tinyint(1) NOT NULL,
  `cms/news` tinyint(1) NOT NULL,
  `cms/newsletter` tinyint(1) NOT NULL,
  `cms/organisation` tinyint(1) NOT NULL,
  `cms/page` tinyint(1) NOT NULL,
  `cms/poll` tinyint(1) NOT NULL,
  `cms/role` tinyint(1) NOT NULL,
  `cms/settings` tinyint(1) NOT NULL,
  `cms/subscriptions` tinyint(1) NOT NULL,
  `cms/switch` tinyint(1) NOT NULL,
  `cms/user` tinyint(1) NOT NULL,
  `cms/weblog` tinyint(1) NOT NULL,
  `cms/language` tinyint(1) NOT NULL,
  `cms/weblog/comment` tinyint(1) NOT NULL,
  `cms/webshop/article` tinyint(1) NOT NULL,
  `webshop/checkout` tinyint(1) NOT NULL,
  `webshop/orders` tinyint(1) NOT NULL,
  `cms/webshop/order` tinyint(1) NOT NULL,
  `cms/webshop/category` tinyint(1) NOT NULL,
  `cms/link` tinyint(1) NOT NULL,
  `cms/link/category` tinyint(1) NOT NULL,
  `cms/photos/album` tinyint(4) DEFAULT '0',
  `cms/photos/collection` tinyint(4) DEFAULT '0',
  `cms/photos/photo` tinyint(4) DEFAULT '0',
  `cms/reroute` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Administrator',0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1),(2,'User',1,1,1,1,1,1,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,1,1,0,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `session_id` varchar(128) NOT NULL,
  `login_id` varchar(128) DEFAULT NULL,
  `content` text,
  `expire` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(50) NOT NULL,
  `bind_to_ip` tinyint(1) NOT NULL,
  `name` tinytext,
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_id` (`session_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(32) NOT NULL,
  `type` varchar(8) NOT NULL,
  `value` varchar(256) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'admin_page_size','integer','25'),(31,'photo_page_size','integer','10'),(5,'default_language','string','en'),(32,'photo_thumbnail_height','integer','100'),(9,'start_page','string','homepage'),(10,'webmaster_email','string','info@banshee-php.org'),(30,'forum_page_size','string','25'),(12,'forum_maintainers','string','Moderator'),(13,'guestbook_page_size','integer','10'),(14,'guestbook_maintainers','string','Publisher'),(15,'news_page_size','integer','5'),(16,'news_rss_page_size','string','30'),(17,'newsletter_bcc_size','integer','100'),(18,'newsletter_code_timeout','string','15 minutes'),(19,'newsletter_email','string','void@banshee-php.org'),(20,'newsletter_name','string','Hugo Leisink'),(36,'contact_email','string','void@banshee-php.org'),(22,'poll_max_answers','integer','10'),(44,'poll_bans','string\n',''),(24,'weblog_page_size','string','5'),(25,'weblog_rss_page_size','integer','30'),(26,'head_title','string','Banshee'),(27,'head_description','string','Secure PHP framework'),(28,'head_keywords','string','banshee, secure, php, framework'),(33,'photo_image_height','integer','450'),(35,'secret_website_code','string','pCNRguvCpG3PnwFj0ASApXVa9OiBuoc9'),(37,'photo_thumbnail_width','integer','100'),(38,'photo_image_width','integer','700'),(39,'hiawatha_cache_default_time','integer','3600'),(40,'photo_album_size','integer','18'),(41,'hiawatha_cache_enabled','boolean','false'),(42,'session_timeout','integer','1000'),(43,'session_persistent','boolean','false'),(46,'database_version','integer','1'),(47,'webshop_page_size','integer','15'),(48,'webshop_order_page_size','integer','5');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_articles`
--

DROP TABLE IF EXISTS `shop_articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shop_articles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `shop_category_id` int(10) unsigned NOT NULL,
  `article_nr` varchar(50) NOT NULL,
  `title` varchar(100) NOT NULL,
  `short_description` tinytext NOT NULL,
  `long_description` text NOT NULL,
  `image` tinytext NOT NULL,
  `price` decimal(7,2) unsigned NOT NULL,
  `visible` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_category_id` (`shop_category_id`),
  CONSTRAINT `shop_articles_ibfk_1` FOREIGN KEY (`shop_category_id`) REFERENCES `shop_categories` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_articles`
--

LOCK TABLES `shop_articles` WRITE;
/*!40000 ALTER TABLE `shop_articles` DISABLE KEYS */;
INSERT INTO `shop_articles` VALUES (1,1,'00000001','Smart TV','Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.','Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. ','https://www.electronicworldtv.co.uk/blog/http://electronicworldtv.co.uk/blog/wp-content/uploads/2016/02/Smart-TV-iStock_000047234238_Medium-1023x784.jpg',239.50,1),(2,2,'00000003','Game Computer','Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem.','Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna. Sed consequat, leo eget bibendum sodales, augue velit cursus nunc, quis gravida magna mi a libero. Fusce vulputate eleifend sapien. Vestibulum purus quam, scelerisque ut, mollis sed, nonummy id, metus. Nullam accumsan lorem in dui. Cras ultricies mi eu turpis hendrerit fringilla. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; In ac dui quis mi consectetuer lacinia. ','https://www.computer-bestel.nl/images/game-pc-epic-preview.png',799.95,1),(8,1,'00000002','Crappy item','Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.','Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Praesent adipiscing. Phasellus ullamcorper ipsum rutrum nunc. Nunc nonummy metus. Vestibulum volutpat pretium libero. Cras id dui. Aenean ut eros et nisl sagittis vestibulum. Nullam nulla eros, ultricies sit amet, nonummy id, imperdiet feugiat, pede. Sed lectus. Donec mollis hendrerit risus. Phasellus nec sem in justo pellentesque facilisis. Etiam imperdiet imperdiet orci. Nunc nec neque. Phasellus leo dolor, tempus non, auctor et, hendrerit quis, nisi. ','http://us.123rf.com/450wm/rjfiskness/rjfiskness1501/rjfiskness150100010/35070423-remains-of-old-tractor-in-a-junk-and-salvage-yard.jpg',128.50,0);
/*!40000 ALTER TABLE `shop_articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_categories`
--

DROP TABLE IF EXISTS `shop_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shop_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_categories`
--

LOCK TABLES `shop_categories` WRITE;
/*!40000 ALTER TABLE `shop_categories` DISABLE KEYS */;
INSERT INTO `shop_categories` VALUES (1,'Electronics'),(2,'Computers');
/*!40000 ALTER TABLE `shop_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_order_article`
--

DROP TABLE IF EXISTS `shop_order_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shop_order_article` (
  `shop_article_id` int(10) unsigned NOT NULL,
  `shop_order_id` int(10) unsigned NOT NULL,
  `quantity` int(11) NOT NULL,
  `article_price` decimal(7,2) NOT NULL,
  KEY `shop_article_id` (`shop_article_id`),
  KEY `shop_order_id` (`shop_order_id`),
  CONSTRAINT `shop_order_article_ibfk_1` FOREIGN KEY (`shop_article_id`) REFERENCES `shop_articles` (`id`),
  CONSTRAINT `shop_order_article_ibfk_2` FOREIGN KEY (`shop_order_id`) REFERENCES `shop_orders` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_order_article`
--

LOCK TABLES `shop_order_article` WRITE;
/*!40000 ALTER TABLE `shop_order_article` DISABLE KEYS */;
INSERT INTO `shop_order_article` VALUES (2,1,1,799.95),(1,2,2,239.50);
/*!40000 ALTER TABLE `shop_order_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_orders`
--

DROP TABLE IF EXISTS `shop_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shop_orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `timestamp` datetime NOT NULL,
  `name` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `zipcode` varchar(7) NOT NULL,
  `city` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `closed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `shop_orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_orders`
--

LOCK TABLES `shop_orders` WRITE;
/*!40000 ALTER TABLE `shop_orders` DISABLE KEYS */;
INSERT INTO `shop_orders` VALUES (1,1,'2016-10-31 16:05:42','Administrator','x','x','x','The Netherlands',1),(2,1,'2016-10-31 16:12:31','Administrator','x','x','x','The Netherlands',0);
/*!40000 ALTER TABLE `shop_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscriptions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_address` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriptions`
--

LOCK TABLES `subscriptions` WRITE;
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_role`
--

DROP TABLE IF EXISTS `user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_role` (
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  KEY `role_id` (`role_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_role_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `user_role_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_role`
--

LOCK TABLES `user_role` WRITE;
/*!40000 ALTER TABLE `user_role` DISABLE KEYS */;
INSERT INTO `user_role` VALUES (1,1),(2,2);
/*!40000 ALTER TABLE `user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `organisation_id` int(10) unsigned NOT NULL,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `password` varchar(128) NOT NULL,
  `one_time_key` varchar(128) DEFAULT NULL,
  `cert_serial` int(10) unsigned DEFAULT NULL,
  `status` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `authenticator_secret` varchar(16) DEFAULT NULL,
  `fullname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `organisation_id` (`organisation_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`organisation_id`) REFERENCES `organisations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,'admin','cc5491f3f6075377579ec9be075c710e9ece5e50ab4f4fa2477c7d201cf72998','G5gtxyqDjhSxIfvpzXMSprlT0pmV1u',NULL,2,NULL,'Administrator','admin@banshee-php.org'),(2,1,'user','68554aeee9e1b820869dc9073cb61d7439c4fb672d24f650ba689b2351942e41',NULL,NULL,2,NULL,'Normal user','user@banshee-php.org');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weblog_comments`
--

DROP TABLE IF EXISTS `weblog_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weblog_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weblog_id` int(10) unsigned NOT NULL,
  `author` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ip_address` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `weblog_id` (`weblog_id`),
  CONSTRAINT `weblog_comments_ibfk_1` FOREIGN KEY (`weblog_id`) REFERENCES `weblogs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weblog_comments`
--

LOCK TABLES `weblog_comments` WRITE;
/*!40000 ALTER TABLE `weblog_comments` DISABLE KEYS */;
INSERT INTO `weblog_comments` VALUES (1,1,'Hugo','Test comment','2015-06-02 17:20:36','84.106.86.135'),(2,1,'Hugo','Another test comment.','2015-06-02 17:21:07','84.106.86.135');
/*!40000 ALTER TABLE `weblog_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weblog_tagged`
--

DROP TABLE IF EXISTS `weblog_tagged`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weblog_tagged` (
  `weblog_id` int(10) unsigned NOT NULL,
  `weblog_tag_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`weblog_id`,`weblog_tag_id`),
  KEY `weblog_tag_id` (`weblog_tag_id`),
  CONSTRAINT `weblog_tagged_ibfk_1` FOREIGN KEY (`weblog_id`) REFERENCES `weblogs` (`id`),
  CONSTRAINT `weblog_tagged_ibfk_2` FOREIGN KEY (`weblog_tag_id`) REFERENCES `weblog_tags` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weblog_tagged`
--

LOCK TABLES `weblog_tagged` WRITE;
/*!40000 ALTER TABLE `weblog_tagged` DISABLE KEYS */;
INSERT INTO `weblog_tagged` VALUES (1,1),(1,4);
/*!40000 ALTER TABLE `weblog_tagged` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weblog_tags`
--

DROP TABLE IF EXISTS `weblog_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weblog_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tag` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tag` (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weblog_tags`
--

LOCK TABLES `weblog_tags` WRITE;
/*!40000 ALTER TABLE `weblog_tags` DISABLE KEYS */;
INSERT INTO `weblog_tags` VALUES (4,'Dolor sit'),(1,'lorum ipsum');
/*!40000 ALTER TABLE `weblog_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weblogs`
--

DROP TABLE IF EXISTS `weblogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weblogs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `visible` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `weblogs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weblogs`
--

LOCK TABLES `weblogs` WRITE;
/*!40000 ALTER TABLE `weblogs` DISABLE KEYS */;
INSERT INTO `weblogs` VALUES (1,1,'Lorum ipsum','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean ac elit quam. Nullam aliquam justo et nisi dictum pretium interdum tellus hendrerit. Aenean tristique posuere dictum. Maecenas nec sapien ut magna suscipit euismod quis ut metus. Aenean sit amet metus a turpis iaculis mollis. Nam faucibus mauris vel ligula ultricies dapibus. Nullam quis orci ac sem convallis malesuada nec id nisi. Praesent quis tellus nec sapien viverra blandit at ut erat. Curabitur bibendum malesuada erat, in suscipit leo porta et. Cras quis arcu sit amet nibh molestie mollis eu eget nulla. Vivamus sed enim fringilla elit pretium feugiat. Nullam elementum fermentum nunc in sodales.</p>\r\n\r\n<p>Mauris nec nunc quis enim porttitor consectetur at et lorem. Vivamus ac rutrum sapien. Nullam metus lectus, lobortis sit amet vulputate sit amet, fermentum sed velit. Phasellus ac libero urna. Maecenas tellus massa, ultrices sed pretium non, faucibus ut lorem. Donec aliquam vehicula ante, eu sodales felis ullamcorper at. Sed sed odio ipsum. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nullam laoreet tristique est in molestie. Sed lacinia euismod porttitor. Praesent ullamcorper fringilla arcu sit amet viverra. Aliquam erat volutpat.</p>\r\n\r\n<p>Nulla vel eros quam. Nam nec turpis ac turpis pulvinar facilisis non non nunc. Nam bibendum nunc in velit cursus rutrum. Integer at ultricies orci. Suspendisse vitae sodales dui. Integer malesuada hendrerit dui, a ullamcorper mauris aliquam sit amet. Nulla dignissim tortor accumsan velit laoreet non eleifend massa aliquet. Quisque luctus dapibus viverra. Aliquam sed lorem diam. Phasellus condimentum lectus vitae ipsum molestie a vestibulum risus malesuada. Duis posuere urna a arcu facilisis sit amet blandit lacus tempus. Vestibulum vel arcu nunc, ut imperdiet massa. Donec congue risus nec urna laoreet et euismod magna semper. Fusce pharetra porttitor ultrices.</p>','2013-04-30 08:20:07',1);
/*!40000 ALTER TABLE `weblogs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-04-11  9:54:23
